//#pragma once
#ifndef APPSETTINGS_H
#define APPSETTINGS_H

 

const char* const ROBOT_COMMAND_INPUT_FILE_PATH = "P:\\";
const char* const ROBOT_COMMAND_INPUT_FILE_NAME = "commands.txt";
 
#endif


